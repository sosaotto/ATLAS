const winston = require('winston');

const logger = winston.createLogger({
    level: 'info',
    format: winston.format.json(),
    defaultMeta: {
        service: 'backend-service'
    },
    transports: [
        new winston.transports.File({
            filename: 'logs/info.log',
            level: 'info',
            json: true,
            format: winston.format.combine(winston.format.timestamp({
                format: 'DD.MM.YYYY HH:mm:ss'
            }), winston.format.json())
        })
    ],
});

module.exports = logger;