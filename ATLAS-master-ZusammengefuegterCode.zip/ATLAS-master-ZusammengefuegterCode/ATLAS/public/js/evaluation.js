socket.on('changeOpacity', opacity => {
    changeOpacity(opacity);
})


function getDate() {
    let d = new Date();
    let day = d.getDate();
    let month = d.getMonth() + 1;
    let year = d.getFullYear();
    let HH = d.getUTCHours() + 1;
    let MM = d.getUTCMinutes() + 1;
    let SS = d.getUTCSeconds() + 1;
    let date = `${day}.${month}.${year} ${HH}:${MM}:${SS}`;
    return date;
}


function changeOpacity(data) {
    // Workaround ZIM
    if (data.logStatus) console.log(`f changeOpacity , ${data.opacity} , ` + getDate());
    document.getElementById('creator').style.backgroundColor = `rgb(0,0,0,${data.opacity})`;
}

socket.on('changeUser', user => {
    changeUser(user);
})


function changeUser(data) {
    // Workaround ZIM
    if (data.logStatus) console.log(`f changeUser , ${data.user} , ` + getDate());
    document.getElementById('user-amount').innerHTML = data.user;
}