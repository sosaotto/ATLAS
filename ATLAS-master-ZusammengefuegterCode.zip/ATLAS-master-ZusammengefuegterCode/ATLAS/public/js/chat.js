document.addEventListener("DOMContentLoaded", function (event) {
    let queryString = window.location.search;
    const isCreator = new URLSearchParams(queryString).get('creator');
    const roomName = new URLSearchParams(queryString).get('room');
    const username = new URLSearchParams(queryString).get('username');

    let fired = false;
    let studentFeedbackDiv = document.getElementById('student-feedback')

    if (isCreator != 'SMNTSDLN') {

        // Left mousedown
        document.getElementById('creator').addEventListener("mousedown", (event) => {
            console.log('Mousedown!')
            if (event.target.id === 'datausage' || event.target.id === 'imprint') {
                return;
            }
            if (event.button === 0) {
                console.log('Left mouse!')
                if (!fired) {
                    fired = true;
                    studentFeedbackDiv.style.backgroundColor = "lightblue";
                    socket.emit('startLog', roomName);
                }
            }
        })

        // Left mouseup
        document.getElementById('creator').addEventListener("mouseup", event => {
            console.log('Mouseup!')
            if (event.target.id === 'datausage' || event.target.id === 'imprint') {
                return;
            }
            console.log(event.target)
            if (event.button === 0) {
                fired = false;
                studentFeedbackDiv.style.backgroundColor = "white";
                socket.emit('stopLog', roomName);
            }

        })

        document.getElementById('footer-information').remove();



        // Mobile solution
        document.getElementById('creator').addEventListener("touchstart", event => {
            if (event.target.id === 'datausage' || event.target.id === 'imprint') {
                return;
            }

            if (!fired) {
                fired = true;
                studentFeedbackDiv.style.backgroundColor = "lightblue";
                socket.emit('startLog', roomName);
            }

            console.log('touchstart')
            const onTouchMove = () => {
                // handle touchmove here
                console.log('onTouchMove')
            }
            const onTouchEnd = () => {
                console.log('onTouchEnd')
                fired = false;
                studentFeedbackDiv.style.backgroundColor = "white";
                socket.emit('stopLog', roomName);
                event.target.removeEventListener("touchmove", onTouchMove);
                event.target.removeEventListener("touchend", onTouchEnd);
                // handle touchend here
            }
            event.target.addEventListener("touchmove", onTouchMove);
            event.target.addEventListener("touchend", onTouchEnd);
            // handle touchstart here







        })


        // touchcancel specially for mobile Chrome
        document.getElementById('creator').addEventListener("touchend touchcancel", event => {
            console.log(event.type)
            if (event.target.id === 'datausage' || event.target.id === 'imprint') {
                return;
            }
            fired = false;
            studentFeedbackDiv.style.backgroundColor = "white";
            socket.emit('stopLog', roomName);

        })




        // keyCode 17 = CTRL-Key
        document.addEventListener("keydown", event => {
            console.log(event)
            if (event.keyCode === 17) {
                if (!fired) {
                    fired = true;
                    studentFeedbackDiv.style.backgroundColor = "lightblue";
                    socket.emit('startLog', roomName);
                }
            }
        })

        document.addEventListener("keyup", event => {
            if (event.keyCode === 17) {
                fired = false;
                studentFeedbackDiv.style.backgroundColor = "white";
                socket.emit('stopLog', roomName);
            }
        })
    }

    let studyUrlValue = document.getElementById("study-url-value");
    studyUrlValue.value = window.location.href.replace("SMNTSDLN", "atlas");

    document.getElementById("btn-copy-url").addEventListener("click", copyURL, false);
    document.getElementById("btn-create-qrcode").addEventListener("click", () => {
        socket.emit('generateQRCode', window.location.href.replace("SMNTSDLN", "atlas"))
    })

    function copyURL() {
        copyText = document.getElementById("study-url-value");
        copyText.select();
        document.execCommand("copy");
        alert("URL was copied to the clipboard.");
    }


    creatorDiv = document.getElementById('creator');
    studentDiv = document.getElementById('student');

    if (isCreator === 'SMNTSDLN') {
        console.log('isCreater', isCreator)
        document.getElementById('student-feedback').remove();
        document.getElementById('room-information').remove();
    } else {
        document.getElementById('collapsible').disabled = true
    }


    function changeOpacity() {
        let sliderValue = document.getElementById('slider-opacity').value;
        socket.emit('changeOpacity', {
            opacity: sliderValue,
            roomName: roomName,
            isCreator: isCreator
        });
    }

});