document.addEventListener("DOMContentLoaded", function (event) {
    let queryString = window.location.search;
    const isCreator = new URLSearchParams(queryString).get('creator');
    const roomName = new URLSearchParams(queryString).get('room');

    if (isCreator != 'SMNTSDLN') {
        document.getElementById("Button").remove();

        //Meldebutton
        document.getElementById("frage_icon").addEventListener("mousedown", (event) => {
            if (wert === true){
                socket.emit("stopMeldung");
            }
            else{
                socket.emit("startMeldung");
            }

        })

        // Verständnisbutton
        document.getElementById('button').addEventListener("click", (event) => {
            if (wertGluehbirne === false){
                socket.emit("stopHealth", roomName);
            }
            if (wertGluehbirne === true){
                socket.emit("startHealth", roomName);
            }})


        document.getElementById('footer-information').remove();



    }

    let studyUrlValue = document.getElementById("study-url-value");
    studyUrlValue.value = window.location.href.replace("SMNTSDLN", "atlas");

    document.getElementById("btn-copy-url").addEventListener("click", copyURL, false);
    document.getElementById("btn-create-qrcode").addEventListener("click", () => {
        socket.emit('generateQRCode', window.location.href.replace("SMNTSDLN", "atlas"))
    })



    //Starten/Stoppen der Vorlesung & Feedback
    document.getElementById("StartVorlesung").addEventListener("dblclick", () => {
        var minuten = vorlesungVorbei()
        socket.emit("feedback", minuten)
    })

    //Feedback abgeben
    document.getElementById("button5").addEventListener("click", () => {
        var feedbackDaten = checkRadio();
        socket.emit("abgeben", feedbackDaten)
    })

    function copyURL() {
        copyText = document.getElementById("study-url-value");
        copyText.select();
        document.execCommand("copy");
        alert("URL was copied to the clipboard.");
    }


    creatorDiv = document.getElementById('creator');
    studentDiv = document.getElementById('student');

    if (isCreator === 'SMNTSDLN') {
        console.log('isCreater', isCreator)
        document.getElementById('student-feedback').remove();
        document.getElementById('room-information').remove();
    } else {
        document.getElementById('collapsible').disabled = true
    }

    //Meldungen zurücksetzen
    if (isCreator === 'SMNTSDLN') {
        document.getElementById("lehrendenMeldungen").addEventListener("mousedown", (event) => {
            socket.emit("zurucksetzen")

        })
    }

});