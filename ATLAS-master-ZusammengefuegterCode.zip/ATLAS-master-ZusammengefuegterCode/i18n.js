/**
 * require I18n with capital I as constructor
 */
const {
    I18n
} = require('i18n')
const path = require('path');

/**
 * create a new instance with it's configuration
 */
const i18n = new I18n({
    locales: ['en'],
    directory: path.join(__dirname, 'locales'),
    defaultLocale: 'en',
    queryParameter: 'lang',
    cookie: 'lang',
    updateFiles: false,
    register: global,
    objectNotation: true,
    api: {
        __: 't', // now req.__ becomes req.t
        __n: 'tn' // and req.__n can be called as req.tn
    },
})

module.exports = i18n;