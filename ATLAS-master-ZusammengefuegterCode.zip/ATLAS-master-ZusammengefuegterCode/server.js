require('dotenv').config();
const logger = require('./utils/logger');

let logStatus = process.env.LOGGING;
let problemClients = new Set();
let MeldeClients = new Set();
let healthClients = new Set();

const path = require('path');
const http = require('http');
const express = require('express');
const socketio = require('socket.io');



//const qr = require('./utils/qrcode');
const qr = require('qrcode')
const {
    userJoin,
    userLeave,
    getCurrentUser,
    getRoomUsers
} = require('./utils/users');


const i18n = require('./i18n');
const {
    __
} = require('./i18n');


const app = express();
const server = http.createServer(app);
const io = socketio(server, {
    pingTimeout: 1000
});

// set the view engine to ejs
app.set('view engine', 'ejs');



// Set static folder
app.use(express.static(path.join(__dirname, 'public')));
app.use(i18n.init)


var redis = require("redis");
const {
    type
} = require('os');
const {
    write
} = require('./utils/logger');
var client = redis.createClient();

client.on("connect", function () {
    console.log("Redis client - You are now connected");
});



app.get('/api/room/:id', function (req, res) {
    client.get(req.params.id, function (err, reply) {
        console.log(typeof reply);
        return res.json({
            // If the room exists typeof equals Object else String
            "message": (typeof reply === 'object') ? 0 : reply
        });

    });

})

app.get('/', function (req, res) {
    res.render('index', {
        title: 'AGB',

    });
})

app.get('/survey', function (req, res) {
    res.render('survey', {
        title: 'Survey',

    });
})

app.get('/room', function (req, res) {


    res.render('room', {
        title: 'Room',
        AGREEMENT: process.env.AGREEMENT,
    });
})



app.get('/tool', function (req, res) {
    console.log(req)

    res.render('tool', {
        title: 'Tool'
    });
})

app.get('/imprint', function (req, res) {
    res.render('imprint', {
        title: 'Imprint'
    });
})

app.get('/datausage', function (req, res) {
    res.render('datausage', {
        title: 'Data Usage'
    });
})

app.get('/feedback', function (req, res) {
    res.render('feedback', {
        title: 'Feedback'
    });
})

// Agreement
if (process.env.AGREEMENT === 'true') {
    io.use((socket, next) => {

        let token = socket.handshake.auth.agreement;
        if (!token) {
            return next(new Error("You need to accept the terms and conditions."));
        } else {
            return next();
        }




    });
}

function writeLog(data) {
    console.log('WRITEOG');
    if (process.env.LOGGING === 'true') {
        console.log('LOGGED');
        console.log(
            data.type,
            data.socket,
            data.time
        )
        logger.info('changeOpacity', {
            'roomName': `${data.roomName}`, //
            'type': `${data.type}`,
            'socket': `${data.socket}`,
            'opacity': `${data.opacity}`,
            'totalClients': `${data.totalClients}`,
            'problemClients': `${data.problemClients}`
        });
    }
}


// Run when client connects
io.on('connection', socket => {

    console.log('Connection socket', socket.rooms)
    socket.on('joinRoom', ({
        username,
        room,
        creator
    }) => {
        const user = userJoin(socket.id, username, room, creator);
        socket.join(room);
        calculateNewHealth(room, "DH");
        console.log('Socket.rooms', socket.rooms)
        console.log(io.sockets.adapter.rooms)

        socketAdapterRooms = io.sockets.adapter.rooms
        console.log('socketAdapterRooms', socketAdapterRooms)

        // Send users and room info
        io.to(user.room).emit('roomUsers', {
            room: user.room,
            users: getRoomUsers(user.room)
        });
    });



    socket.on('generateQRCode', (roomURL) => {
        user = getCurrentUser(socket.id)
        console.log('GQRC', roomURL)
        qr.toDataURL(roomURL, function (err, url) {
            io.to(user.id).emit('generateQRCode', url)
        })

    })

    // Feedback
    socket.on("feedback", (minuten) => {
        user = getCurrentUser(socket.id)
        io.in(user.room).emit('feedback', minuten);
    })

    socket.on("abgeben", (feedbackDaten) => {
        user = getCurrentUser(socket.id)
        io.in(user.room).emit('abgeben', feedbackDaten)
    })

    //Meldungen
    function calculateMeldungen(roomName, type) {
        console.log('calculateMeldungen roomName', roomName);

        MeldeClientsSize = MeldeClients.size;
        const user = getCurrentUser(socket.id);

        writeLog({
            roomName: roomName,
            type: type,
            socket: socket.id,
            MeldeClients: MeldeClientsSize
        })

        console.log('user.room', user.room);
        client.set(user.room, MeldeClientsSize, function (err, reply) {
            console.log(reply);
        });

        io.in(user.room).emit('changeMeldungen', {
            Meldungen: MeldeClientsSize,
            logStatus: logStatus
        })
    }

    function Bildaendern(roomName, type){
        const user = getCurrentUser(socket.id);
        MeldeClients.clear()
        wert2 = false;
        io.in(user.room).emit("changeBild", {
            Meldungen: MeldeClients.size,
            wert2: wert2
        })
    }

    socket.on('startMeldung', (roomName) => {
        MeldeClients.add(socket.id)
        calculateMeldungen(roomName, "M");

    })
    socket.on("stopMeldung", (roomName) => {
        MeldeClients.delete(socket.id)
        calculateMeldungen(roomName, "M");

    })

    socket.on("zurucksetzen", (roomName) => {
        Bildaendern(roomName, "Z");
    })

    // Verständnisskala
    function calculateNewHealth(roomName, type) {
        console.log('calculateNewHealth roomName', roomName);

        totalClientsHealth = io.sockets.adapter.rooms.get(roomName);
        console.log(totalClientsHealth);
        healthClientsSize = healthClients.size;

        if (typeof (totalClientsHealth) == 'undefined') {
            totalClientsHealthSize = 1;
        } else {
            totalClientsHealthSize = (totalClientsHealth.size - 1); //-1
        }


        procent = (healthClientsSize / totalClientsHealthSize);
        console.log(`${healthClientsSize} : ${totalClientsHealthSize}`);

        const user = getCurrentUser(socket.id);


        console.log('Health clients', healthClientsSize);
        console.log('TotalClientsHealth clients', totalClientsHealthSize);
        console.log('Procent ', procent);

        writeLog({
            roomName: roomName,
            type: type,
            socket: socket.id,
            healthStatus: procent,
            totalClients: totalClientsHealthSize,
            healthClients: healthClientsSize
        })

        console.log('user.room', user.room);
        client.set(user.room, procent, function (err, reply) {
            console.log(procent);
            console.log(reply);
        });

        io.to(user.room).emit('changeHealthStatus', {
            HealthStatus: procent,
            logStatus: logStatus,
        })

    }

    socket.on('startHealth', (roomName) => {
        healthClients.add(socket.id)
        calculateNewHealth(roomName, "DH");
    })

    socket.on('stopHealth', (roomName) => {
        healthClients.delete(socket.id)
        calculateNewHealth(roomName, "UH");
    })

    function calculateProzent(roomName, type) {
        console.log('calculateProzent roomName', roomName);

        totalClientsHealth = io.sockets.adapter.rooms.get(roomName);
        console.log(totalClientsHealth);
        healthClientsSize = healthClients.size;

        if (typeof (totalClientsHealth) == 'undefined') {
            totalClientsHealthSize = 1;
        } else {
            totalClientsHealthSize = (totalClientsHealth.size - 1); //-1
        }


        procent = (healthClientsSize / totalClientsHealthSize);
        prozent = (1.0-procent) * 100;

        return prozent
    }

    socket.on("prozent", (roomName) => {
        var prozent = calculateProzent(roomName, "XH");
        const user = getCurrentUser(socket.id);
        io.in(user.room).emit('prozent', prozent);
    })

    socket.on('changeUser', userAmount => {
        console.log(userAmount);
        console.log(logStatus);
        const user = getCurrentUser(socket.id);
        io.to(user.room).emit('changeUser', {
            user: userAmount,
            logStatus: logStatus
        })
    })

    socket.on('reconnect', () => {
        console.log('Reconnected!')
    });

    socket.on('disconnect', (reason) => {
        console.log('DISCONNECT', socket.id, reason);
        console.log('Problemclients', problemClients)

        //Remove socket from healthclients and meldeclients if connection aborted while button is pressed
        healthClients.delete(socket.id);
        MeldeClients.delete(socket.id);

        const current_user = getCurrentUser(socket.id);
        calculateNewHealth(current_user.room)
        calculateMeldungen(current_user.room)

        const user = userLeave(socket.id);
        console.log(user)
        if (user) {
            // Send users and room info
            io.to(user.room).emit('roomUsers', {
                room: user.room,
                users: getRoomUsers(user.room)
            });
        }

    });
});

const PORT = process.env.PORT || 1337;

server.listen(PORT, () => console.log(`Server running on port ${PORT}`));
console.log(`Server on Port ${PORT}`)